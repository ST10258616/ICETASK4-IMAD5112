package com.kyle.icetask4

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.animation.ObjectAnimator
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private lateinit var questTV: TextView
    private lateinit var opt1: Button
    private lateinit var opt2: Button
    private lateinit var opt3: Button
    private lateinit var scoreTV: TextView
    private lateinit var retrybtn: Button
    private lateinit var view: View

    private val questions = listOf(
        Question("What is the capital of France?", listOf("Madrid", "Berlin", "Paris"), "Paris"),
        Question("Which planet is known as the Red Planet?", listOf("Earth", "Mars", "Venus"), "Mars"),
        Question( "Which is the fastest animal in the world?,", listOf("Falcon", "Cheetah", "Deer"), "Cheetah"),
        Question( "Who wrote the play Romeo and Juliet?", listOf("William Shakespeare", "Charles Dickens", "Jane Austin"), "William Shakespeare"),
        Question( "Which gas is most abundant in the Earth's atmosphere?", listOf("Oxygen", "Nitrogen", "Carbon dioxide"), "Carbon dioxide")
    )

    private var currentQuestionIndex = 0
    private var score = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        updateQuestion()

        opt1.setOnClickListener { checkAnswer(opt1.text.toString()) }
        opt2.setOnClickListener { checkAnswer(opt2.text.toString()) }
        opt3.setOnClickListener { checkAnswer(opt3.text.toString()) }

        retrybtn.setOnClickListener {
            currentQuestionIndex = 0
            score = 0
            updateQuestion()
        }
    }

    private fun updateQuestion() {
        if (currentQuestionIndex < questions.size) {
            val currentQuestion = questions[currentQuestionIndex]
            questTV.text = currentQuestion.question
            opt1.text = currentQuestion.options[0]
            opt2.text = currentQuestion.options[1]
            opt3.text = currentQuestion.options[2]
        } else {

            showScore()
        }
    }

    private fun checkAnswer(selectedOption: String) {
        val currentQuestion = questions[currentQuestionIndex]
        if (selectedOption == currentQuestion.correctAnswer) {
            score++
        }
        currentQuestionIndex++
        updateQuestion()
    }

    private fun showScore() {
        val animator = ObjectAnimator.ofFloat(scoreTV, View.ALPHA, 0f, 1f)
        animator.interpolator = AccelerateInterpolator()
        animator.duration = 1000
        animator.start()

        scoreTV.text = "Score: $score / ${questions.size}"
        retrybtn.visibility = View.VISIBLE

    }
}

data class Question(val question: String, val options: List<String>, val correctAnswer: String)